%%% process data
%%% in the old model, consumer profiles are synchrinized with system
%%% profiles

%% read system profile
SystemProfile = csvread('SystemProfile.csv', 0, 0, [0,0,8760-1,0]);
SystemProfile5D = csvread('SystemProfile5D.csv', 0, 0, [0,0,120-1,0]);
%% creat consumer profile
ConsumerProfile5D = repmat(SystemProfile5D', 1000, 1);
ConsumerProfile = repmat(SystemProfile', 1000, 1);
%% output consumer profile
csvwrite('ConsumerProfile5D.csv',ConsumerProfile5D);
csvwrite('ConsumerProfile.csv',ConsumerProfile);

